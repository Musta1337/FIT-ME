<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>LogIN</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <form>
            <h1>SIGN UP</h1>
            <p>Please Fill this form to create an account</p>
            <label>User Name</label>
            <input type="text" id=user name="user" placeholder="User Name">
            <label>Password</label>
            <input type="password" id=password name="password" placeholder="password">
            <label>Confirm Password</label>
            <input type="confirm password" id=confirm password name="password" placeholder="password">
            <button type="submit">SIGN UP</button>
            <p>Already have an account? <a href="login.html">LOG IN</a>.</p>
        </form>
    </body>
</html>